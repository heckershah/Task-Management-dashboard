export default function CardWrapper({ title, children }){
    return(
    <div className="card">
      <h2>{title}</h2>
      {children}
    </div>
  );
}