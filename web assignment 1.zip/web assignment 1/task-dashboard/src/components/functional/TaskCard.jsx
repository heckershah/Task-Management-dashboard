import { useContext } from "react";
import { ThemeContext } from "../../context/ThemeContext";

export default function TaskCard({ task, onComplete, onDelete }) {
    // Get the current theme
    const { theme } = useContext(ThemeContext);
    return (
    <div className={`task-item ${theme}`}>
      <span> {task.title} - {task.completed ? "Completed" : "Pending"}</span>
      <button onClick={() => onComplete(task.id)}>
        {task.completed ? "Undo" : "Complete"}
      </button>

      <button onClick={() => onDelete(task.id)}>
        Delete
      </button>
    </div>
  );
}