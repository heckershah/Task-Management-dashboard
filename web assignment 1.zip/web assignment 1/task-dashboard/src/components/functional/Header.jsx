import { useContext } from "react";
import { ThemeContext } from "../../context/ThemeContext";

export default function Header({ tasks }){
    const { theme, toggleTheme} = useContext(ThemeContext);

    //Count pending tasks
    const pending = tasks.filter((task) => !task.completed).length;

    return(
    <header>
      <h1>Task Dashboard</h1>
      <p>Pending Tasks: {pending}</p>
      <button onClick={toggleTheme}>Change Theme ({theme})</button>
    </header>
  );
}


