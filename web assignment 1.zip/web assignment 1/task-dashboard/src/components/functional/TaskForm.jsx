import { useState, useRef, useEffect } from "react";
import CardWrapper from "./CardWrapper";

export default function TaskForm({ onAddTask }) {
  const [title, setTitle] = useState("");

  // Reference to the input field
  const inputRef = useRef(null);
  // Focus input when the form first appears
  useEffect(() => {
    inputRef.current.focus();
  }, []);

  function handleSubmit(event){
    event.preventDefault();
    // Do not add an empty task
    if (title.trim() === "") return;
    // Send the task to App.jsx
    onAddTask(title);
    // Clear the input and focus it again
    setTitle("");
    inputRef.current.focus();
  }

  return (
    <CardWrapper title="Add Task">
      <form onSubmit={handleSubmit}>
        <input ref={inputRef} value={title}  placeholder="Enter task name"
          onChange={(event) => setTitle(event.target.value)}/>
        <button type="submit">Add Task</button>
      </form>
    </CardWrapper>
  );
}