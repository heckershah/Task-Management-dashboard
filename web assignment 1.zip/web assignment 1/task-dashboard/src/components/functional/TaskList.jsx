import { useState, useMemo } from "react";
import TaskCard from "./TaskCard";
import CardWrapper from "./CardWrapper";

export default function TaskList({ tasks, onComplete, onDelete, onActivity }) {
    const [filter, setFilter] = useState("All");

    // Filter tasks when tasks or filter changes
    const filteredTasks = useMemo(() => {
      if(filter === "All") return tasks;
      if (filter === "Completed") {
        return tasks.filter((task) => task.completed);
      }
      return tasks.filter((task) => !task.completed);
    },[tasks, filter]);

    return(
    <CardWrapper title="My Tasks">
      <select value={filter} onChange={(event) => {
            setFilter(event.target.value);
            onActivity("Changed task filter");}}>
        <option value="All">All Tasks</option>
        <option value="Pending">Pending</option>
        <option value="Completed">Completed</option>
      </select>
      {filteredTasks.length === 0 && <p>No tasks found.</p>}

      {filteredTasks.map((task) =>(
        <TaskCard key={task.id} task={task}
          onComplete={onComplete} onDelete={onDelete}/>))}
      </CardWrapper>
    );
  }
