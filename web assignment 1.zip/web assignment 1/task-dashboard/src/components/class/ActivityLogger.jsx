import { Component } from "react";
import CardWrapper from "../functional/CardWrapper";

class ActivityLogger extends Component {
  constructor(props) {
    super(props);

    // Store all activity messages
    this.state = {
      logs: []
    };
  }

  // Load previous activities when the component opens
  componentDidMount() {
    try {
      const savedLogs = localStorage.getItem("logs");
      if (savedLogs) {
        const parsedLogs = JSON.parse(savedLogs);
        if (Array.isArray(parsedLogs)) {
          this.setState({ logs: parsedLogs });
        }
      }
    } catch (error) {
      console.log("Unable to load activity logs.");
    }
  }

  // Respond when a new activity arrives
  componentDidUpdate(previousProps, previousState) {
    // Check whether the activity prop has changed
    if (
      this.props.activity &&
      this.props.activity !== previousProps.activity
    ) {
      const newLog = {
        id: this.props.activity.id,
        message: this.props.activity.message,
        time: new Date().toLocaleTimeString()
      };
      // Add the new activity to the top of the list
      this.setState((oldState) => ({
        logs: [newLog, ...oldState.logs]
      }));
      return;
    }

    // Save logs only when the log list changes
    if (previousState.logs !== this.state.logs) {
      localStorage.setItem(
        "logs",
        JSON.stringify(this.state.logs)
      );
    }
  }

  // No timers or listeners need cleanup in this version
  componentWillUnmount() {
  }
  render() {
    return (
      <CardWrapper title="Activity Logger">
        {this.state.logs.length === 0 ? (
          <p>No activity yet. Add, complete, or delete a task.</p>
        ) : (
          <ul>
            {this.state.logs.map((log) => (
              <li key={log.id}>
                <strong>{log.message}</strong>
                <br />
                <small>{log.time}</small>
              </li>
            ))}
          </ul>
        )}
      </CardWrapper>
    );
  }
}
export default ActivityLogger;