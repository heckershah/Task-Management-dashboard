import {useState,useEffect,useCallback,useContext} from "react";
import Header from "./components/functional/Header";
import TaskForm from "./components/functional/TaskForm";
import TaskList from "./components/functional/TaskList";
import ActivityLogger from "./components/class/ActivityLogger";
import {ThemeProvider,ThemeContext}from "./context/ThemeContext";
import "./index.css";

function Dashboard() {
  // Load previously saved tasks
  const [tasks, setTasks] = useState(() => {
    try{
      return JSON.parse(localStorage.getItem("tasks")) || [];
    } catch {
      return [];
    }
  });

  // Store the latest activity
  const [activity, setActivity] = useState(null);
  // Get the current theme
  const { theme } = useContext(ThemeContext);
  // Save tasks whenever they change
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  // Update browser tab title
  useEffect(() => {
    const pending = tasks.filter(
      (task) => !task.completed
    ).length;

    document.title = `${pending} Pending Tasks`;
  }, [tasks]);

  // Add a new task
  const addTask = useCallback((title) => {
    const newTask = {
      id: Date.now(),
      title: title,
      completed: false
    };

    setTasks((oldTasks) => [...oldTasks, newTask]);

    // Send an activity message to the logger
    setActivity({
      id: Date.now() + Math.random(),
      message: `Added task: ${title}`
    });
  }, []);

  // Complete or undo a task
  const completeTask = useCallback((id) => {
    const selectedTask = tasks.find(
      (task) => task.id === id
    );

    if (!selectedTask) return;

    setTasks((oldTasks) =>
      oldTasks.map((task) =>
        task.id === id
          ? { ...task, completed: !task.completed }
          : task
      )
    );

    setActivity({
      id: Date.now() + Math.random(),
      message: selectedTask.completed ? `Marked pending: ${selectedTask.title}`
        : `Completed: ${selectedTask.title}`
    });
  }, [tasks]);

  // Delete a task
  const deleteTask = useCallback((id) => {
    const selectedTask = tasks.find(
      (task) => task.id === id
    );

    if (!selectedTask) return;

    setTasks((oldTasks) =>
      oldTasks.filter((task) => task.id !== id)
    );

    setActivity({
      id: Date.now() + Math.random(),
      message: `Deleted task: ${selectedTask.title}`
    });
  }, [tasks]);

  // Record other activities, such as changing a filter
  function recordActivity(message) {
    setActivity({
      id: Date.now() + Math.random(),
      message: message
    });
  }

  return (
    // Apply the theme to the complete dashboard
    <div className={`app ${theme}`}>
      <Header tasks={tasks} />
      <main>
        <TaskForm onAddTask={addTask} />
        <TaskList tasks={tasks} onComplete={completeTask}
          onDelete={deleteTask} onActivity={recordActivity}/>
        <ActivityLogger activity={activity} />
      </main>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <Dashboard />
    </ThemeProvider>
  );
}

export default App;